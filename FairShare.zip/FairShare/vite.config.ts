import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    // The leading dot acts as a wildcard for all subdomains
    allowedHosts: ['.replit.dev'], 
  }
})